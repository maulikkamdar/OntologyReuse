['COL10A1', 'MMP11', 'ADAMTS5', 'KLHL29', 'SPRY2', 'HOXA4', 'NEK2', 'PER1', 'TPX2', 'PPP1R12B', 'FAM126A']
['PER1', 'NR4A1', 'F10', 'APOLD1', 'GSTM5', 'KLF2', 'HAAO', 'FXYD1', 'CSGALNACT1', 'ERAL1', 'PHYHIP']
['KRT80', 'ESM1', 'FOXQ1', 'BEST4', 'ETV4', 'KIAA1199', 'TEAD4', 'WNT2', 'GLTP', 'CLDN1', 'COL11A1']
['BEST4', 'KIAA1257', 'FOXQ1', 'KIAA1199', 'ETV4', 'ESM1', 'GLTP', 'CLDN1', 'TEAD4', 'WNT2', 'MTHFD1L']
['DLG2', 'GPT2', 'ARTN', 'GPD1L', 'NFIX', 'FAM3D', 'EXT1', 'SERPINH1', 'FAM107A', 'QARS', 'INHBA']
['PYCR1', 'RTKN2', 'KANK3', 'RAMP2', 'LIMS2', 'WWC2', 'ACTN2', 'TAL1', 'CLEC3B', 'EPAS1', 'FABP4']
['FAM83B', 'ESAM', 'KIF23', 'TMEM88', 'S1PR1', 'SLC2A1', 'PLK1', 'PRC1', 'C15orf42', 'CLEC3B', 'CDCA5']
['AMACR', 'PYCR1', 'HIST3H2A', 'ETNK2', 'DOK4', 'CTF1', 'APOBEC3C', 'MARCKSL1', 'CRYAB', 'EPHA10', 'AOX1']


a = open("liberal/BRCA_sigGeneAnalyFileExp.tsv")
alines = a.readlines()
aGenes = [x.strip().split("\t")[0].strip() for x in alines]

b = open("liberal/BRCA_sigGeneAnalyFileMeth.tsv")
blines = b.readlines()
bGenes = [x.strip().split("\t")[0].strip() for x in blines]

for k in d:
    aParams = alines[aGenes.index(k)].strip().split("\t")
    bParams = blines[bGenes.index(k)].strip().split("\t")
    print k + "\t" + aParams[len(aParams)-1] + "\t" + bParams[len(bParams)-1]

