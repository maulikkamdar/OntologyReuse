var extractedNodes = [], extractedLinks = [], goNodes = [];
var nodeLocator = [], linkLocator = [], clusterLocator = [];
var count = 0, linkCount = 0, clusterCount = 0;
var colorPalette = ["#FDD9B5", "#1F75FE", "#FF2B2B", "#76FF7A", "#FB7EFD", "#FFCF48"];
var popUp;
var nodecounter = 0, subclassCounter = 0, linkCounter = 0;

executeSparql("concepts");
executeSparql("subclass");
executeSparql("properties");

function executeSparql(dataset) {
	var url = "data/" + dataset + ".json"; 
	
	$('.splashScreenExplorer').show();
	$.ajax({
		url: url,
	    aync: true,
	    success: function (json) {
	    	//var dataParts = json.split('<body>');
	    	//var data = JSON.parse(dataParts[dataParts.length-1].split('</body>')[0]);
	    	var data = json;
	    	console.log(data);
	    	switch(dataset) {
	    		case "concepts" : createConceptNodes(data.results.bindings); break;
	    		case "subclass" : iterateTillRet(data.results.bindings, "subclass");;
	    		case "properties" : iterateTillRet(data.results.bindings, "properties"); break;
	    	}
	    }
	});
}

function iterateTillRet(data, type){
//	console.log(data);
	var myInterval = setInterval (function (){
		if(nodecounter){
			clearInterval(myInterval);
			if(type == "subclass")
				createSubClassLinks(data);
			else
				createPropertyLinks(data);
		}
	},1000);
}

var linkInterval = setInterval (function (){
	if(subclassCounter && linkCounter){
		clearInterval(linkInterval);
		$('.splashScreenExplorer').hide();
		initVisualization(extractedNodes, extractedLinks);
	}
},1000);

function createSubClassLinks(data){
//	console.log(data);
	for(i in data){
		if(typeof data[i].supclass !== "undefined"){
			var conceptNodeId = nodeLocator[data[i].o.value];
			var supClassId = nodeLocator[data[i].supclass.value];
		/*	if(typeof supClassId === "undefined"){
				var supNodeName = data[i].supclass.value.split(/[:#\/]/);
				var noMappings = 1;
				if(jQuery.inArray('mappings.roadmap.org', supNodeName) < 0) {
					var nodeType = "concept";
					var cluster = "C1"
				} else {
					var nodeType = "mappings";
					var cluster = "C4";
				}
				var supClassNode = createNode(supNodeName[supNodeName.length-1], data[i].supclass.value, 
						nodeType, "", 10, cluster);
				supClassId = supClassNode.id;
			}
			if(typeof conceptNodeId === "undefined") {
				var conceptNodeName = data[i].o.value.split(/[:#\/]/);
				if(jQuery.inArray('mappings.roadmap.org', conceptNodeName) < 0) {
					var nodeType = "concept";
					var cluster = "C1"
				} else {
					var nodeType = "mappings";
					var cluster = "C4";
				}
				var conceptNode = createNode(conceptNodeName[conceptNodeName.length-1], data[i].o.value, 
						nodeType, "", 10, cluster);
				conceptNodeId = conceptNode.id;
			} */
			if(typeof supClassId !== "undefined" && typeof conceptNodeId != "undefined"){
				var newLink = {"id": linkCount++, "source": supClassId, "target": conceptNodeId, "value": 1, "color": "#0000ff"};
				extractedLinks.push(newLink);
				var supConceptNode = extractedNodes[supClassId];
				supConceptNode.children.push(conceptNodeId);
				supConceptNode.size++;
				var conceptNode = extractedNodes[conceptNodeId];
				conceptNode.description += "<br>" + "<b>SubClassOf</b> " + supConceptNode.label;
			}
		}
	}
	subclassCounter = 1;
	//initVisualization(extractedNodes, extractedLinks);
}

function createPropertyLinks(data){
	for(i in data){
		var property = (typeof data[i].prop !== "undefined") ? data[i].prop.value : "";
		var propertyParts = property.split(/[:#\/]/);
		property = propertyParts[propertyParts.length-1];
		
		if(typeof data[i].domain !== "undefined" && typeof data[i].range !== "undefined"){
			var domainId = nodeLocator[data[i].domain.value];
			var rangeId = nodeLocator[data[i].range.value];
			
			if(typeof domainId !== "undefined" && typeof rangeId != "undefined"){
				var newLink = {"id": linkCount++, "source": domainId, "target": rangeId, "value": 2, "color": "#000000"};
				extractedLinks.push(newLink);
				var domainNode = extractedNodes[domainId];
				var rangeNode = extractedNodes[rangeId];
				
				domainNode.description += "<br><b>Domain of</b> "+ property + " <b>Range is</b> "+ rangeNode.label;
				rangeNode.description += "<br><b>Range of</b> " + property + " <b>Domain is </b> "+ domainNode.label;
			}
			
			if(data[i].range.value == "http://www.w3.org/2000/01/rdf-schema#Literal"){
				var description = "<b>Range of</b> " + extractedNodes[domainId].label; 
				var literalNode = createNode(property, data[i].prop.value, "literal", description, 10, "C2");
				var newLink = {"id": linkCount++, "source": literalNode.id, "target": domainId, "value": 1, "color": "#ff0000"};
				extractedLinks.push(newLink);
				literalNode.children.push(domainId);
				
				var domainNode = extractedNodes[domainId];
				domainNode.description += "<br><b>Domain of</b> "+ property + " (Literal)";
			}
			
			if(data[i].range.value == "http://purl.org/dc/dcmitype/InteractiveResource"){
				var description = "<b>Range of</b> " + extractedNodes[domainId].label; 
				var literalNode = createNode(property, data[i].prop.value, "literal", description, 10, "C3");
				var newLink = {"id": linkCount++, "source": literalNode.id, "target": domainId, "value": 1, "color": "#00ff00"};
				extractedLinks.push(newLink);
				literalNode.children.push(domainId);
				
				var domainNode = extractedNodes[domainId];
				domainNode.description += "<br><b>Domain of</b> "+ property + " (Interactive Resource)";
			}
		}
	}
	linkCounter = 1;
}

function createNode(name, uri, type, description, size, cluster) {
	if(nodeLocator[uri] == null) {
		var endpoints = [];
		if(type != "literal") {
			endpoints.push(description);
			description = uri + "<br><b>Source Endpoint</b> <br>" + description
		} else {
			description = uri + "<br>" +description;
		}
		var node = {"id": count, "type": type, "name" : name, "label": name, "children": [], 
				"description": description, "size": size, "url": uri, "cluster": cluster, "endpoints": endpoints};
		//node.endpoints.push(description);
		nodeLocator[uri] = count++;
		extractedNodes.push(node);
	} else {
		var node = extractedNodes[nodeLocator[uri]];
		if(type != "literal") {
			var omit = 1;
			for(i in node.endpoints) {
				if(description == node.endpoints[i]) {
					omit = 0;
				}
			}
			if(omit)
				node.description += "<br>" + description;
			node.size = node.size+5;
			if(node.name == "" && name != "")
				node.name = name;
		} else {
			node.description += "<br>" + description;
		}
	}
	return node;
}

function getCluster(endpoint){
	if (clusterLocator[endpoint] == null) {
		clusterLocator[endpoint] = "C" + clusterCount;
		cluster = "C" + clusterCount++;
	} else 
		cluster = clusterLocator[endpoint];
	return cluster;
}

function createConceptNodes(data){
	for(i in data){
	//	var cluster = getCluster(data[i].s.value); // Used for coloring nodes per endpoint - not needed.
		var uriParts = data[i].o.value.split(/[:#\/]/);
		var include = 0;
		var size = 20;
		for(j in uriParts) {
			if(uriParts[j] == "granatum") {
				include = 1;
				break;
			}
			if(uriParts[j] == "mappings.roadmap.org") {
				include = 2;
				break;
			}
		}
		if(include == 1) {
			var cluster = "C0";
		//	size = 40;
		} else if (include == 2)
			var cluster = "C4";
		else
			var cluster = "C1";
		var label = (typeof data[i].label !== "undefined") ? data[i].label.value : data[i].o.value;
		var conceptNode = createNode(label, data[i].o.value, "concept", data[i].s.value, size, cluster);
	}
//	$('.splashScreenExplorer').hide();
//	initVisualization(extractedNodes, extractedLinks);
	nodecounter = 1;
}

function initVisualization(transformedNodes, transformedLinks) {
  // Instanciate sigma.js and customize it :
	var sigInst = sigma.init(document.getElementById('sigmaViz')).drawingProperties({
		"borderSize": 1,//Something other than 0
        "nodeBorderColor": "default",//exactly like this
        "defaultNodeBorderColor": "#000",//Any color of your choice
        "defaultBorderView": "always",//apply the default color to all nodes always (normal+hover)
		"defaultEdgeType": 'curve',
		"labelThreshold": 7,
		"minEdgeSize": 1,
		"maxEdgeSize": 3,
		"defaultLabelColor": '#000'		
	});
 
	var i, N = transformedNodes.length, E = transformedLinks.length, C = 5, d = 0.5, clusters = [];
	for(i = 0; i < 5; i++){
		clusters.push({
			'id': 'C'+i,
			'nodes': [],
			'color': colorPalette[i]
		});
	}
	
	for(i = 0; i < N; i++){
		var size = (Math.sqrt(transformedNodes[i].size));
		var cluster = clusters[transformedNodes[i].cluster.substring(1,transformedNodes[i].cluster.length)];
		sigInst.addNode(transformedNodes[i].id,{
			'x': Math.random(),
			'y': Math.random(),
			'size': size,
			'color': cluster['color'],
			'cluster': cluster['id'],
			'label': transformedNodes[i].label,
			'attributes': transformedNodes[i].description
		});
		cluster.nodes.push(transformedNodes[i].id);
	}
 
	for(i = 0; i < E; i++){
		sigInst.addEdge(transformedLinks[i].id, transformedLinks[i].source, transformedLinks[i].target, 
				{'size': transformedLinks[i].value, 'color': transformedLinks[i].color});
	}
 
  // Start the ForceAtlas2 algorithm
  // (requires "sigma.forceatlas2.js" to be included)
	sigInst.startForceAtlas2();
 
	setTimeout(function(){
		sigInst.stopForceAtlas2();
		sigInst
		.bind('overnodes',function(event){
			var nodes = event.content;
			console.log(event);
		    var neighbors = {};
		    sigInst.iterEdges(function(e){
		    	if(nodes.indexOf(e.source)>=0 || nodes.indexOf(e.target)>=0){
		    		neighbors[e.source] = 1;
		    		neighbors[e.target] = 1;
		    	}
		    }).iterNodes(function(n){
		    	if(!neighbors[n.id]){
		    		n.hidden = 1;
		    	}else{
		    		n.hidden = 0;
		    	}
		    	if (n.id == nodes[0])
		    		n.hidden = 0;   	
		    }).draw(2,2,2);
		})
		.bind('outnodes',function(){
			sigInst.iterEdges(function(e){
				e.hidden = 0;
		    }).iterNodes(function(n){
		    	n.hidden = 0;
		    }).draw(2,2,2);
		});
		/*.bind('downnodes',function(event){
			var node;
			sigInst.iterNodes(function(n){
				node = n;
			},[event.content[0]]);
			clearCanvas();
			click(node["label"]);
		});*/
		sigInst.bind('overnodes',showNodeInfo).bind('outnodes',hideNodeInfo).draw();
		
		function hideNodeInfo(event) {
			popUp && popUp.remove();
		      popUp = false;
		}
		
		function showNodeInfo(event) {
		    popUp && popUp.remove();

		    var node;
		    sigInst.iterNodes(function(n){
		      node = n;
		    },[event.content[0]]);
		    
		    console.log( node);
		    var text = "<b>" + node.label + "</b><br>" + node['attributes'];
		    
		    popUp = $(
		            '<div class="node-info-popup"></div>'
		          ).append(
		            text
		          ).attr(
		            'id',
		            'node-info'+sigInst.getID()
		          ).css({
		            'display': 'inline-block',
		    'width' : '300px',
		    'overflow' : 'hidden',
		            'border-radius': 3,
		            'padding': 15,
		            'background-color': 'rgba(000,000,000,0.8)',
		            'color': '#fff',
		            'box-shadow': '0 0 4px #666',
		            'position': 'absolute',
		            'left': node.displayX,
		            'top': node.displayY+25
		          });

		          $('ul',popUp).css('margin','0 0 0 20px');

		          $('#sigmaViz').append(popUp);
		}
	},5000);
}

function updateInterface(entityId){
	clearCanvas();
	click(entityId);
}

function allUpdate(){
	clearCanvas();
	initVisualization(extractedNodes, extractedLinks);
}

function clearCanvas(){
	$('#sigmaViz').remove();
	$("#sigmaViz-parent").append('<div id="sigmaViz" class="sigmaViz"></div>');
	$('#sigmaViz').html('');
}
//init();
