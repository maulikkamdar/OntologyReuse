function renderPopUp (json, resource, label, resourceType) {
	if(label.length > 10)
		var truncatedLabel = label.substring(0,8) + "...";
	else 
		var truncatedLabel = label;
	
	var resourceTerms = resource.split(/[:#\/]/);
	var resourceTerm = makeid() + resourceTerms[resourceTerms.length-1] ;
	
	var selector = "#" + resourceTerm;
	$infoTabs.tabs('add',selector, truncatedLabel);  
	$('.splashScreenExplorer').hide();
	
	if (resourceType != null) {
        var imageUrl = (typeof resourceType.headerImage !== "undefined")? resourceType.headerImage.replace(/IDENTIFIER/g, resourceTerms[resourceTerms.length-1]);
        var imageTag = (urlExists(imageUrl)) ? "<img src=\"" + imageUrl + "\">": "";
    }
    
	d3.select(selector).html("<h4 class='sidebar'>" + label + "</h4><br>" + imageTag);
	
	d3.select(selector).append("table").attr("border","0px").selectAll("tr").data(json).enter().append("tr").html(function(d){
		var cellValue;
		
		if(d.object.substring(0,4) == 'http'){
			var uriTerms = d.object.split(".");
			var ext = uriTerms[uriTerms.length-1];
            hasDefinedView = false;
            for (i in resourceType.objectExp) {
                if (resourceType.objectExp[i].term == ext) {
                    cellValue = resourceType.objectExp[i].html.replace(/OBJECT/g, d.object).replace(/RESOURCETAB/g, resourceTerm);
                    hasDefinedView = true;
                    break;
                }
            }
			if (!hasDefinedView) {
				cellValue = "<a href=javascript:popUpInfo(\'"+d.object+"\')>"+d.object+"</a>";
			}
		}
		switch(d.predicate){
			for (i in resourceType.objectExp) {
                if (resourceType.objectExp[i].term == ext) {
                    cellValue = resourceType.objectExp[i].html.replace(/OBJECT/g, d.object).replace(/PREDICATE/g, d.object).replace(/RESOURCETAB/g, resourceTerm);
                    hasDefinedView = true;
                }
            }
			if (!hasDefinedView) {
				cellValue = "<a href=javascript:popUpInfo(\'"+d.object+"\')>"+d.object+"</a>";
			}
		}
		return "<th>"+d.predicate+"</th><td class='infoTableCell'>"+
			((d.object.substring(0,4) == 'http' || d.predicate == 'packagedBy') ? cellValue : d.object)+
			"</td>";
	});
	
	if(structure){
		loadStructure(resourceTerm, structureFile);
	}
}


// Create the XHR object.
function createCORSRequest(method, url) {
  var xhr = new XMLHttpRequest();
  if ("withCredentials" in xhr) {
    // XHR for Chrome/Firefox/Opera/Safari.
    xhr.open(method, url, true);
  } else if (typeof XDomainRequest != "undefined") {
    // XDomainRequest for IE.
    xhr = new XDomainRequest();
    xhr.open(method, url);
  } else {
    // CORS not supported.
    xhr = null;
  }
  return xhr;
}

function makeCorsRequest(url, resourceTerm) {
  var xhr = createCORSRequest('GET', url);
  if (!xhr) {
    console.log('CORS not supported');
    return;
  }

  // Response handlers.
  xhr.onload = function() {
    var data = xhr.responseText;
    $('#' + resourceTerm + 'sdf_src').val(data);
    new GLmol(resourceTerm+'sdf');
  };

  xhr.onerror = function() {
    console.log('Woops, there was an error making the request.');
  };

  xhr.send();
}

function loadStructure(resourceTerm, structureFile){
	var sdf_source;
        makeCorsRequest(structureFile, resourceTerm);
        /*var structureURL = window.location.protocol + "//" + window.location.host + window.location.pathname + "crossDomFileRet.php?id=" + structureFile + "&location=" + structureRepo ;
	$.ajax({
		url: structureURL,
		type: 'GET',
		async: false
	}).done(function ( data ) {
		console.log(data);
		$('#' + resourceTerm + 'sdf_src').val(data);
		new GLmol(resourceTerm+'sdf');
	});*/
}

function urlExists(url, callback){
  $.ajax({
    type: 'HEAD',
    url: url,
    success: function(){
      callback(true);
    },
    error: function() {
      callback(false);
    }
  });
}

var $infoTabs = $( "#additionalTabs" ).tabs({
	tabTemplate: "<li><a href='#{href}'>#{label}</a> <span class='ui-icon ui-icon-close'>Remove Tab</span></li>",
    add: function(event, ui) {
    //	console.log(ui);
        $infoTabs.tabs('select', '#' + ui.panel.id);
    }
});

$( "#additionalTabs span.ui-icon-close" ).live("click", function() {
	console.log('here');
	var index = $( "li", $infoTabs ).index( $( this ).parent() );
	$infoTabs.tabs( "remove", index );
});

$("#autoComSearchBox").click(function(){
	if  ($('#autoComSearchBox').val() != ''){
    	$('#autoComSearchBox').val('')}
});