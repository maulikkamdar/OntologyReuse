var defaultService = "http://cu.drugbank.bio2rdf.org/sparql";
var dataTypes = [];

function readConfig() {
    d3.json('data/bio2rdfconfig.json', function (data) {
        console.log(data);
        for (i in data.types){
            dataTypes[data.types[i].name] = data.types[i];
        }
    });
}

function showDataTable(entity) {
    console.log(dataTypes);
    
	if(typeof dataTypes[entity.category] !== "undefined") {
		var uriStr = (typeof dataTypes[entity.category].service !== "undefined") ? dataTypes[entity.category].service : defaultService;
        var additionalQuery = dataTypes[entity.category].query.replace(/ENTITYURI/g, entity.entity);
        var resourceMeta = dataTypes[entity.category];
	} else {
		var additionalQuery = "SELECT DISTINCT * WHERE { " +
			"?s ?p ?o }";
        var uriStr = defaultService;
        var resourceMeta = null;
	}
	
	//console.log(additionalQuery);
	  
	var queryMap = { 'query': additionalQuery, 'output' : 'json', 'endpoint': uriStr};
	$('.splashScreenExplorer').show();
	
	$.post("makeRequest.php", queryMap, function(json){
		var dataParts = json.split('<body>');
	    var data = JSON.parse(dataParts[dataParts.length-1].split('</body>')[0]);
		
		//console.log(data);
		var infoTokenArray =[];
		for(delta in data.results.bindings) {
			var binding = data.results.bindings[delta];
			var predicateTerms = binding["p"].value.split(/[:#\/]/);
			var predicateTerm = predicateTerms[predicateTerms.length-1]; //Usually the Type
			var objectTerm = binding["o"].value; //This is the main value
			var subjectTerm = binding["s"].value; //URI for extra information
			var infoToken = {"subject" : subjectTerm, "predicate": predicateTerm, "object": ""+ objectTerm};
			infoTokenArray.push(infoToken);
		}
		
		//console.log(infoTokenArray);
		renderPopUp(infoTokenArray, entity.entity, entity.value, resourceMeta);
   	}).fail(function() {
	   	$('.splashScreenExplorer').hide();
	});  
}

readConfig();