<?php 

function constructQuery($query, $url)
{
   $format = 'sparql-results+json';
 
   $searchUrl = $url . '?'
      .'query='.urlencode($query)
      .'&Accept=application/'.urlencode($format); // change to Accept for HCLS workbench
	  
   return $searchUrl;
}
 
 
function request($url)
{
   if (!function_exists('curl_init')){ 
      die('CURL is not installed!');
   }
   $ch= curl_init();
 
   curl_setopt($ch, 
      CURLOPT_URL, 
      $url);
 
   curl_setopt($ch, 
      CURLOPT_RETURNTRANSFER, 
      true);
 
   $response = curl_exec($ch);
 
   curl_close($ch);
 
   return $response;
}

$dataset = $_GET['dataset'];
$url = "http://hcls.deri.org:8080/openrdf-sesame/repositories/roadmap";
//$url = "http://srvgal78.deri.ie/sparql";

switch($dataset) {
	case "concepts" : $query = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
								PREFIX void-ext:<http://rdfs.org/ns/void-ext#>
								PREFIX void:<http://rdfs.org/ns/void#>
								SELECT DISTINCT * WHERE {
									?s void:class ?o .
									OPTIONAL {?o rdfs:label ?label} 
									FILTER(!STRSTARTS(STR(?o), \"http://mappings.roadmap.org/\"))
								}";
					break;
	case "subclass" : $query = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
								PREFIX void-ext:<http://rdfs.org/ns/void-ext#>
								PREFIX void:<http://rdfs.org/ns/void#>
								SELECT DISTINCT * WHERE {
									{?o rdfs:subClassOf ?supclass} UNION {?o void-ext:subClassOf ?supclass}
									FILTER(!STRSTARTS(STR(?o), \"http://mappings.roadmap.org/\"))
								}";
					break;
	case "properties" : $query = "PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
								PREFIX void-ext:<http://rdfs.org/ns/void-ext#>
								PREFIX void:<http://rdfs.org/ns/void#>
								SELECT DISTINCT * WHERE {
									?prop void-ext:domain ?domain .
									?prop void-ext:range ?range .
									FILTER (?prop != rdf:type)
									FILTER (?prop != rdf:Literal)
									FILTER(!STRSTARTS(STR(?domain), \"http://mappings.roadmap.org/\"))
									FILTER(!STRSTARTS(STR(?range), \"http://mappings.roadmap.org/\"))
								}";
					break;
}
//echo $query;
$requestURL = constructQuery($query, $url);
$responseArray = request($requestURL);
?>
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
      "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
 
<html xmlns="http://www.w3.org/1999/xhtml">
 
<head>
 
<title>SPARQL Proxy Executor</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>
 
<body><?php echo $responseArray; ?>
</body>
</html>
