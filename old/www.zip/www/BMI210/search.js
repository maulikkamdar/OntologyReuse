packageMetadata  = [];
populating = 0
$('.splashScreenExplorer').show();

d3.tsv("github_repos_meta.tsv", function(tsv) {
    for (dataline in tsv) {
        packageMetadata[tsv[dataline].html_url] = tsv[dataline]
    }
    populating = 1
})


//console.log(packageMetadata["https://github.com/bashi88/Final_Project_ZeaPol"])

var retriever = setInterval(function(){
		if(populating) {
            console.log(packageMetadata["https://github.com/bashi88/Final_Project_ZeaPol"])
			clearInterval(retriever);
			$('.splashScreenExplorer').hide();
		}
	}, 1000);


$("#autoComSearchBox").keyup(function(event){
    if(event.keyCode == 13){
        $("#resultsDiv").empty()

        $('.splashScreenExplorer').show();
        console.log(document.getElementById("autoComSearchBox").value)
        urlQuery = window.location.pathname + "python/testPython.php?query=" +document.getElementById("autoComSearchBox").value+ "&length=30"
        console.log(urlQuery)
        
        $.ajax({
		    url: urlQuery,
	        aync: true,
	        success: function (text) {
	    	    console.log(text)
                getRepositories()
	        }
	    });
    }
});

function getRepositories () {
    d3.tsv(window.location.pathname + "python/recommendations.tsv", function(text){
        for (dataline in text) {
            console.log(text[dataline].name.trim())
            githubRepo = packageMetadata[text[dataline].name.trim()]
            htmlString = '<div class="row-fluid resultDiv"><div class="span12 result" style="text-align:left"><h2>' + githubRepo.name + '&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;<span align="right">('+ text[dataline].score.trim() +')</span>' + 
                         '</h2><hr><h4><a href="' +githubRepo.html_url + '" target="_blank">' + githubRepo.full_name + '</a></h4><p>'+ githubRepo.description + 
                         '</p><p><b>Watchers: </b>' + githubRepo.watcher_count + ',&nbsp; &nbsp; &nbsp;<b>Stargazers: </b>' + githubRepo.stargazer_count + ',&nbsp; &nbsp; &nbsp;<b>Forks: </b>' + githubRepo.forks_count + '</p>' + 
                         '<p><b>Update Date: </b>' + githubRepo.update_date + ',&nbsp; &nbsp; &nbsp;<b>Created Date: </b>' +  githubRepo.create_date + '</p></div></div>';
            $("#resultsDiv").append(htmlString)
        }
        $('.splashScreenExplorer').hide();
    })
}