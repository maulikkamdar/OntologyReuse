<!DOCTYPE html>
<html lang="en-US">
<head>
</head>

<body>
<div align="center" style="top:20px; font-size:20px">
For a better analysis, we will monitor your keyboard and mouse navigation patterns when you are providing your subjective insights and exploring your data. All this information is anonymized.
</div>
</body>