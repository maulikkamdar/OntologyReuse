jQuery(document).ready(function(){
    var timeSlots = [];
    var mostRecent = "";
    var uniqueTimeLoc = [];

    d3.tsv("explore_retrieve.php?option=all", function(data) {    
        for (entry in data) {
            var timestampParts = data[entry]["upload"].split(" ");
            if (timestampParts.length >  1) {
                if (typeof timeSlots[timestampParts[0]] === "undefined") {
                    timeSlots[timestampParts[0]] = {"times": [timestampParts[1]]};
                    uniqueTimeLoc.push(timestampParts[0]);
                    mostRecent = timestampParts[0];
                } else  {
                    timeSlots[timestampParts[0]]["times"].push(timestampParts[1])
                }
            }
        }
        console.log(mostRecent);
        for (time = uniqueTimeLoc.length; time > 0; time--) {
            jQuery("#loggeddays").append("<option value=" + uniqueTimeLoc[time-1] + ">"+ uniqueTimeLoc[time-1] + "</option>");
        }
    });

    var width = 0.96*window.innerWidth;
    var height = 400; // window.innerHeight - 320 // window.innerHeight - 200
    var baseLength = 0.05;
    var baseHrmHeight = 1.5;
    var topHrmHeight = baseHrmHeight*200;
    var baseLlHeight = 0.06; 
    var topLlHeight = baseLlHeight*5000;
    var bottomHeight = 20;
    var startTime = 6;
    var endTime = 22;
    var trackLength = (endTime-startTime)*3600*baseLength + 50;
    
    var colors = ["#000000", "#ffffff"];

    var trackCanvas = new Kinetic.Stage({
        container: 'trackCanvas',
        width: width,
        height: height, 
    });

    var lstaticTrackLayer = new Kinetic.Layer({
        width: 50
    });

    var rstaticTrackLayer = new Kinetic.Layer({
        x: width - 50,
        width: 50
    });

    var dynamicTrackLayer = new Kinetic.Layer({
        width: width - 100,
        x: 50,
        draggable: true,
        dragBoundFunc: function(pos) {
            var newX =  pos.x > 50 ? 50 : pos.x;
            return {
                x: newX,
                y: this.getAbsolutePosition().y
            }
        }
    });

    var yAxis = new Kinetic.Line({
        points: [0, 0, 0, height],
        stroke: 'black',
        strokeWidth: 2,
        lineJoin: 'round',
        opacity: 0.1
    });

    dynamicTrackLayer.add(yAxis);

    var lstaticLayerBg = new Kinetic.Rect({
        x: 0,
        y: 0,
        width: 50,
        height: height,
        fill: '#fff',
        stroke: '#cccccc',
        opacity: 1,
        strokeWidth: 1
    });

    
    var rstaticLayerBg = new Kinetic.Rect({
        x: 0,
        y: 0,
        width: 50,
        height: height,
        fill: '#fff',
        stroke: '#cccccc',
        opacity: 1,
        strokeWidth: 1
    });

    var hrmRangeVals = new Kinetic.Group();
    for (i = 0; i < 11; i++) {
        var valLoc = height - bottomHeight - i*30 - 18;
        var hrmPrint = i*20;
        var hrmVal = new Kinetic.Text({
            x: 0,
            y: valLoc,
            text: hrmPrint,
            fontSize: 16,
            fontFamily: 'Calibri',
            fill: '#C10000',
            width: 50,
            fontStyle: "bold",
            padding: 10,
            align: 'right'
        });
        hrmRangeVals.add(hrmVal);
    }

    var llRangeVals = new Kinetic.Group();
    for (i = 0; i < 11; i++) {
        var valLoc = height - bottomHeight - i*30 - 15;
        var llPrint = i*500;
        var llVal = new Kinetic.Text({
            x: 0,
            y: valLoc,
            text: llPrint,
            fontSize: 16,
            fontFamily: 'Calibri',
            fill: '#F6CD03',
            width: 100,
            fontStyle: "bold",
            padding: 6,
            align: 'left'
        });
        llRangeVals.add(llVal);
    }

    lstaticTrackLayer.add(lstaticLayerBg);
    rstaticTrackLayer.add(rstaticLayerBg);
    lstaticTrackLayer.add(hrmRangeVals);
    rstaticTrackLayer.add(llRangeVals);
    trackCanvas.add(dynamicTrackLayer);
    trackCanvas.add(lstaticTrackLayer);
    trackCanvas.add(rstaticTrackLayer);

    var linearTimeGroup = new Kinetic.Group();
    var trackGroup = new Kinetic.Group();

    var completedLength = 0;
    for (i = startTime; i < endTime; i++) {
        var timeElem = new Kinetic.Rect({
            x: completedLength,
            y: 0,
            width: baseLength*3600,
            height: 50,
            fill: "#ffffff",
            stroke: 'black',
            opacity: 0.75,
              //  strokeEnabled: false
        });
        
        linearTimeGroup.add(timeElem);
        for (k = 1; k < 6; k ++) {
            var xVal = completedLength + k*600*baseLength;
            var tenMinDivider = new Kinetic.Line({
                points: [xVal, 50, xVal, 30],
                stroke: 'black',
                strokeWidth: 1,
                lineJoin: 'round'
            });
            linearTimeGroup.add(tenMinDivider);
        }

        var timePrint = (i > 12) ? (i-12) + " PM" : ((i < 12) ? i + " AM" : i + " PM");
        var timeText = new Kinetic.Text({
            x: completedLength,
            y: 0,
            text: timePrint,
            fontSize: 16,
            fontFamily: 'Calibri',
            fill: '#000',
            width: 200,
            padding: 10
        });
        linearTimeGroup.add(timeText);

        completedLength = baseLength*3600 + completedLength;
    }

    var dynamicLayerBg = new Kinetic.Rect({
        x: 0,
        y: 0,
        width: completedLength,
        height: height,
        fill: '#ccc',
        stroke: '#cccccc',
        opacity: 0.1,
        strokeWidth: 1
    });

    dynamicTrackLayer.add(dynamicLayerBg);

    for (i = 0; i < 11; i++) {
        var dividerHeight = height - bottomHeight - i*30;
        var canvasDivider = new Kinetic.Line({
            points: [0, dividerHeight, completedLength, dividerHeight],
            stroke: "#ccc",
            strokeWidth: 1,
            lineJoin: 'round'
        });
        trackGroup.add(canvasDivider);
    }

    dynamicTrackLayer.add(trackGroup);
    dynamicTrackLayer.add(linearTimeGroup);
    dynamicTrackLayer.draw();

    function drawMultiPlot(dataPoints, lineColor) {
        var multiLineSeg = new Kinetic.Group();

        var dataLineSegment = new Kinetic.Line({
            points: dataPoints,
            stroke: lineColor,
            strokeWidth: 2,
            lineJoin: 'round',
            tension: 0
        });

        multiLineSeg.add(dataLineSegment);
                        
        /*var startPoint = new Kinetic.Ring({
            innerRadius: 1,
            outerRadius: 2,
            x: dataPoints[0],
            y: dataPoints[1],
            stroke: lineColor,
            strokeWidth: 1
        });
        
        var endPoint = new Kinetic.Ring({
            innerRadius: 1,
            outerRadius: 2,
            x: dataPoints[dataPoints.length-2],
            y: dataPoints[dataPoints.length-1],
            stroke: lineColor,
            strokeWidth: 1
        });

        multiLineSeg.add(startPoint);
        multiLineSeg.add(endPoint);*/
        return multiLineSeg;
    }
   
    function visualize_tracks(data) {
        var prevTimeStamp = null;
        var prevDataEntry = null;
        var currentDay = null;
        var hrmPoints = [];
        var lightPoints = [];
        var hrmLineGroup = new Kinetic.Group();
        var llLineGroup = new Kinetic.Group();

        for (entry = 0; entry < data.length; entry++) {
            var timestampParts = data[entry].TimeStamp.split(" ");
            if (timestampParts.length >  2) {
                var dayParts = timestampParts[0].split("-");
                var timeParts = timestampParts[1].split(":");
                //new Date(year, month, day, hours, minutes, seconds, milliseconds) 
                var newTimeStamp = new Date(dayParts[0], dayParts[1], dayParts[2], timeParts[0], timeParts[1], timeParts[2], 0);
                var hour = startTime;
                if (timestampParts[2] == "PM" && timeParts[0] < 12)
                    hour = parseInt(timeParts[0]) + 12 - startTime;
                else
                    hour = parseInt(timeParts[0]) - startTime;

                if (hour < 0 || hour > (endTime-startTime))
                    continue;

                var xCoordinate = (hour*3600+ parseInt(timeParts[1])*60 + parseInt(timeParts[2]))*baseLength;

                var hrmVal = data[entry].Heartrate;
                if (hrmVal == "NA" || hrmVal == "0" || entry == data.length-1) {
                    if (hrmPoints.length > 2) {
                        var visPointGroup = drawMultiPlot(hrmPoints, "#C10000");
                        hrmLineGroup.add(visPointGroup);
                        hrmPoints = [];
                    } else if (hrmPoints.length == 2) {
                        var singlePoint = new Kinetic.Ring({
                            innerRadius: 1,
                            outerRadius: 2,
                            x: hrmPoints[0],
                            y: hrmPoints[1],
                            stroke: "#C10000",
                            strokeWidth: 1
                        });
                        hrmLineGroup.add(singlePoint);
                        hrmPoints = [];
                    }
                } else {
                    var yCoordinate = height - bottomHeight - baseHrmHeight*parseInt(hrmVal);
                    if (yCoordinate < height - bottomHeight - topHrmHeight)
                        yCoordinate = height - bottomHeight - topHrmHeight;
                    hrmPoints.push(xCoordinate);
                    hrmPoints.push(yCoordinate);
                }

                var llVal = data[entry].Light;
                if (llVal == "NA" || entry == data.length-1) {
                    if (lightPoints.length > 2) {
                        var visPointGroup = drawMultiPlot(lightPoints, "#F6CD03");
                        llLineGroup.add(visPointGroup);
                        lightPoints = [];
                    } else if (lightPoints.length == 2) {
                        var singlePoint = new Kinetic.Circle({
                            innerRadius: 1,
                            outerRadius: 2,
                            x: lightPoints[0],
                            y: lightPoints[1],
                            stroke: "#F6CD03",
                            strokeWidth: 1
                        });
                        llLineGroup.add(singlePoint);
                        llPoints = [];
                    }
                } else {
                    var yCoordinate = height - bottomHeight - baseLlHeight*parseInt(llVal);
                    if (yCoordinate < height - bottomHeight - topLlHeight)
                        yCoordinate = height - bottomHeight - topLlHeight;
                    lightPoints.push(xCoordinate);
                    lightPoints.push(yCoordinate);
                }
                
                if (prevTimeStamp != null)
                    var timeDiff = newTimeStamp.getTime() - prevTimeStamp.getTime();
                prevTimeStamp = newTimeStamp; 
                //console.log(data[entry].Heartrate);
            }
        }
        
        dynamicTrackLayer.add(llLineGroup);
        dynamicTrackLayer.add(hrmLineGroup);
        dynamicTrackLayer.draw();
    }

   
    var desiredTslots = "";
    var myInterval = setInterval(function(){
        if (timeSlots[mostRecent] !== "undefined") {
            clearInterval(myInterval);
            var recTimes = timeSlots[mostRecent]["times"];
            for (ref in recTimes) {
                desiredTslots = desiredTslots + "\"" + mostRecent + " " + recTimes[ref] + "\",";
            }
            d3.tsv("explore_retrieve.php?option=spec&timeslots=" + desiredTslots.substring(0, desiredTslots.length-1), function(data) {
                visualize_tracks(data);
            });
        }
    }, 1000);
    
    jQuery('#play').click(function() {
        playTrackCounter = setInterval(function(){
            var playWidth = dynamicTrackLayer.getAbsolutePosition().x-dynamicTrackLayer.getWidth()/10;
            dynamicTrackLayer.setAbsolutePosition(playWidth, dynamicTrackLayer.getAbsolutePosition().y);
            dynamicTrackLayer.draw();
            if(playWidth-dynamicTrackLayer.getWidth() < -trackLength) {
                clearInterval(playTrackCounter);
            }
        }, 1000);
    });

    jQuery('#stop').click(function() {
        clearInterval(playTrackCounter);
        dynamicTrackLayer.setAbsolutePosition(50, dynamicTrackLayer.getAbsolutePosition().y);
        dynamicTrackLayer.draw();
    })

    jQuery('#front').click(function() {
        var playWidth = dynamicTrackLayer.getAbsolutePosition().x-dynamicTrackLayer.getWidth();
        if(playWidth > -trackLength) {
            dynamicTrackLayer.setAbsolutePosition(playWidth, dynamicTrackLayer.getAbsolutePosition().y);
            dynamicTrackLayer.draw();
        }
    });

    jQuery('#back').click(function() {
        var playWidth = dynamicTrackLayer.getAbsolutePosition().x+dynamicTrackLayer.getWidth();
        if(playWidth-dynamicTrackLayer.getWidth() < 0){
            dynamicTrackLayer.setAbsolutePosition(playWidth, dynamicTrackLayer.getAbsolutePosition().y);
            dynamicTrackLayer.draw();
        }
    });
    
    jQuery("#brainview").load(
        "https://brainbrowser.cbrain.mcgill.ca/surface-viewer-widget?" + 
        "version=2.3.0&" + 
        "model=data/realct.obj&" + 
        "color_map=data/spectral.txt&" + 
        "intensity_data=data/realct.txt&" + 
        "width=" + jQuery("#brainview").width() + "&" + 
        "height=" + jQuery("#brainview").height()
    );

    jQuery.getScript("js/monitor_mouse.js", function(){
       console.log("Script loaded and executed.");
    });
});