jQuery("#writeLink").click(function(event) {
    event.preventDefault();
    logInteractions();
    window.location = "index.php"
});

jQuery("#exploreLink").click(function(event) {
    event.preventDefault();
    logInteractions();
    window.location = "explore.php"
});

jQuery("#aboutLink").click(function(event) {
    event.preventDefault();
    logInteractions();
    window.location = "about.php"
});

jQuery("#privacyLink").click(function(event) {
    event.preventDefault();
    logInteractions();
   // window.location = "explore.php"
});

jQuery("#helpLink").click(function(event) {
    event.preventDefault();
    logInteractions();
    //window.location = "help.php"
});

jQuery("#logoutLink").click(function(event) {
    event.preventDefault();
    logInteractions();
    window.location = "logout.php"
});