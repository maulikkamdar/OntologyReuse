<?php
	header("Content-Type: text/plain"); 
	include('session_check.php');
	include('connection.php');
	$option = $_GET["option"];
	if ($option == "all") {
		$query = "SELECT `upload_time` FROM `user_data` WHERE `userid`=15 ORDER BY `upload_time`";
		//$query = "SELECT `upload_time` FROM `user_data` WHERE `userid`=" . $_SESSION['userid'] . " ORDER BY `upload_time`";
		echo "upload\n";
        $data = mysql_query($query);
        while ($row = mysql_fetch_object($data)) {
           echo $row->upload_time . "\n";
        }
	} else {
		$time = $_GET["timeslots"];
		$query = "SELECT `timestamps`, `heart_rate`, `light`, `latitude`, `longitude`, `peak2peak` FROM `user_data` WHERE `userid`=15 AND `upload_time` IN (". $time .") ORDER BY `upload_time`";
		//echo $query;
		//$query = "SELECT `timestamps`, `heart_rate`, `light`, `latitude`, `longitude`, `peak2peak` FROM `user_data` WHERE `userid`=" . $_SESSION['userid'] . " ORDER BY `upload_time` LIMIT 1";
		//echo $query . '<br>';
		echo "TimeStamp\tLight\tHeartrate\tLatitude\tLongitude\tPeak2Peak\n";
		$data =  mysql_query($query);
	    while ($row = mysql_fetch_object($data)) {
	        $lightVals = explode(";", $row->light);
			$timeVals = explode(";", $row->timestamps);
			$heartVals = explode(";", $row->heart_rate);
			$latVals = explode(";", $row->latitude);
			$longVals = explode(";", $row->longitude);
			$p2pVals = explode(";", $row->peak2peak);
	        for ($i = 0 ; $i < count($timeVals); $i++) {
				echo $timeVals[$i] . "\t" . $lightVals[$i] . "\t" . $heartVals[$i] . "\t" . $latVals[$i] . "\t" . $longVals[$i] . "\t" . $p2pVals[$i] . "\n";
			}
		}
    }
    
	
    mysql_close ($connection);
?>