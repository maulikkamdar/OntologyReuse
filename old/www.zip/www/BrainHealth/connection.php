<?php
	$connection = mysql_connect("mysql-user.stanford.edu", "cbiomedin212bm", "teighook"); // Establishing connection with server..
	$db = mysql_select_db("c_biomedin212_bmi212", $connection); // Selecting Database.
?>