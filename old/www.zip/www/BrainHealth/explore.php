<?php include('session_check.php');?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <?php include('header.php'); ?>
    <script src="js/libraries/kinetic.min.js"></script>
</head>

<body>
    <?php include('navbar.php'); ?>
    <div class="container-fluid" style="margin-bottom:10px;">
        <div class="row-fluid">
          <div class="span12">
            <h4 align="center" style="color: #0000ff">This section is still under development, so some widgets may not represent your actual data or insights</h4>
          </div>
        </div>
    </div> 

    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <div class="row-fluid">
                    <div class="span12 explorer" id="trackControls">
                        <select id="loggeddays"></select>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <a class="btn" href="#" id="back"><i class="icon-backward icon-black"></i></a>
                        <a class="btn" href="#" id="play"><i class="icon-play icon-black"></i></a>
                        <a class="btn" href="#" id="stop"><i class="icon-stop icon-black"></i></a>
                        <a class="btn" href="#" id="front"><i class="icon-forward icon-black"></i></a>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    </div>
                </div>
                <div class="row-fluid"><div class="span12 explorer" id="trackCanvas"></div></div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span4" id="brainViz">
                <div class="tabbable" id="braintabs">
                    <ul class="nav nav-tabs" id="tabIds">
                        <li class="active"><a href="#brainview" data-toggle="tab" title="Play with a brain">Brain View</a></li>
                    </ul>
                    <div class="tab-content" id="brainnet">
                        <div id="brainview" class="brainview"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<!--<div class="container-fluid">
		<div class="row-fluid">
            <div class="span4" id="hearrateDiv">
                <div class="tabbable" id="heartrate">
                    <ul class="nav nav-tabs" id="hrvtabIds">
                        <li class="active"><a href="#chr_container" data-toggle="tab">Current Heart Rate</a></li>
                        <li><a href="#vaDiv" data-toggle="tab">Variability Analysis</a></li>
                    </ul>
                    <div class="tab-content" id="hrvtabContents">
                        <div id="chr_container" class="tab-pane active fade in"></div>
                        <div id="vaDiv" align="center" class="tab-pane fade"></div>
                    </div>
                </div>
            </div>
            <div class="span4" id="activityDiv">
                <div class="tabbable" id="activity">
                    <ul class="nav nav-tabs" id="acttabIds">
                        <li class="active"><a href="#steps_container" data-toggle="tab">Steps</a></li>
                        <li><a href="#wrd_container" data-toggle="tab">Walking + Running Distance</a></li>
                        <li><a href="#loc_container" data-toggle="tab">Locations</a></li>
                    </ul>
                    <div class="tab-content" id="acttabContents">
                        <div id="steps_container" class="tab-pane active fade in"></div>
                        <div id="wrd_container" class="tab-pane fade"></div>
                        <div id="loc_container" class="tab-pane fade"></div>
                    </div>
                </div>
            </div>
            <div class="span4" id="sleepDiv">
                <div class="tabbable" id="sleeptabs">
                    <ul class="nav nav-tabs" id="sleepTabIds">
                        <li class="active"><a href="#inout" data-toggle="tab">Indoor Outdoor Activity (Inferred)</a></li>
                        <li><a href="#sleep_container" data-toggle="tab">Sleep Insights (Inferred)</a></li>
                    </ul>
                    <div class="tab-content" id="tabContents">
                        <div id="inout" class="tab-pane active fade in"></div>
                        <div id="sleep_container" class="tab-pane fade"></div>
                    </div>
                </div>
            </div>
		</div>
    </div>
    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span4" id="mentalDiv">
                <div class="tabbable" id="mentalStates">
                    <ul class="nav nav-tabs" id="mentalStatetabs">
                        <li class="active"><a href="#mental_container" data-toggle="tab">Emotional States (Inferred)</a></li>
                    </ul>
                    <div class="tab-content" id="tabContents">
                        <div id="mental_container" class="tab-pane active fade in"></div>
                    </div>
                </div>
            </div>
            <div class="span4" id="brainViz">
                <div class="tabbable" id="braintabs">
                    <ul class="nav nav-tabs" id="tabIds">
                        <li class="active"><a href="#brainview" data-toggle="tab">Brain View</a></li>
                    </ul>
                    <div class="tab-content" id="brainnet">
                        <div id="brainview" class="brainview"></div>
                    </div>
                </div>
            </div>
            <div class="span4" id="chatDiv">
                <div class="tabbable" id="chat">
                    <ul class="nav nav-tabs" id="chattabIds">
                        <li class="active"><a href="#chat_container" data-toggle="tab">Discuss ...</a></li>
                    </ul>
                    <div class="tab-content" id="tabContents">
                        <div id="chat_container" class="tab-pane active fade in"></div>
                    </div>
                </div>
            </div>
        </div>
	</div>-->

    <!--<div class="splashScreenExplorer">
        <img src="img/loading-animation.gif"><img src="img/Insight-JPG.jpg"><br>
        <h2 align="center">Simulating. One moment please…</h2>
    </div>-->

<script type="text/javascript" src="js/explorer.js"></script>
<script type="text/javascript" src="js/navbar.js"></script>
</body></html>
