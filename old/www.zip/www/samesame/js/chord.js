function visualizeit(data) {
  // From http://mkweb.bcgsc.ca/circos/guide/tables/
  //data = eboladata.distance
  terms = []
  for(i=0;i<data.length;i++){
    if(jQuery.inArray(data[i].term1, terms)){
      terms.push(data[i].term1);
    }
    if(jQuery.inArray(data[i].term2, terms)){
      terms.push(data[i].term2);
    } 
  }
  console.log(terms)
  /*r = 0
  for(r=0; r<N; r++) {
    row = [];
    for(c=0; c<r; c++){
      row.push(matrix[c][r]);
    }
    row.push(0.0)
    for(c=r+1; c<N; c++){
      console.log(r)
      //console.log(data[0]['pm_dist']);
      row.push(data.shift()['pm_dist']);
    }
    matrix.push(row);
  }
  console.log(matrix)*/
  var N = 20;//terms.length
  matrix = []
  for(r=0;r<N;r++){
    var row = Array(N)
    matrix.push(row)
  }
  
  for(r=0;r<N;r++){
    matrix[r][r] = 0.0
    for(c=r+1;c<N;c++){
      tm = [terms[r],terms[c]]
      for(i=0;i<data.length;i++){
        if((data[i]['term1'] == tm[0] || data[i]['term1'] == tm[1]) && 
           (data[i]['term2'] == tm[0] || data[i]['term2'] == tm[1])) {
          if(data[i]['pm_dist'] > 1){
            matrix[r][c] = 0.0;
            matrix[c][r] = 0.0;
          } else {
            matrix[r][c] = data[i]['pm_dist'];
            matrix[c][r] = data[i]['pm_dist'];
          }
        }
      }
    }
  }

  /*
  var matrix = [
    [0,2,0,0],
    [0,0,1,0],
    [0,0,0,1],
    [1,0,0,0],
  ];*/

  var chord = d3.layout.chord()
      .padding(.05)
      .sortSubgroups(d3.descending)
      .matrix(matrix);

  var width = 960,
      height = 500,
      innerRadius = Math.min(width, height) * .41,
      outerRadius = innerRadius * 1.1;

  var fill = d3.scale.ordinal()
      .domain(d3.range(matrix.length))
      .range(['rgb(166,206,227)','rgb(31,120,180)','rgb(178,223,138)','rgb(51,160,44)','rgb(251,154,153)','rgb(227,26,28)','rgb(253,191,111)','rgb(255,127,0)','rgb(202,178,214)','rgb(106,61,154)']);

  var chordD = d3.select("#chord").append("svg")
      .attr("width", width)
      .attr("height", height)
    .append("g")
      .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

  groups = chordD.append("g").selectAll("path")
      .data(chord.groups)
    .enter().append("path")
    .attr("class","chord-group")
      .style("fill", function(d) { return fill(d.index); })
      .style("stroke", function(d) { return fill(d.index); })
      .style("cursor","pointer")
      .attr("d", d3.svg.arc().innerRadius(innerRadius).outerRadius(outerRadius))
      .on("mouseover", fade(.1))
      .on("mouseout", function(){
          d3.selectAll(".chord path").style("opacity",1);
        })
      .on("click", function(d) { 
                var link = 'http://www.ncbi.nlm.nih.gov/pubmed?term='+terms[d.index]+'[MeSH Major]';
                window.open(link); })
      .append("svg:title")
      .text(function(d) { return terms[d.index]; })

  chordD.append("g")
      .attr("class", "chord")
    .selectAll("path")
      .data(chord.chords)
    .enter().append("path")
    .on("click", function(d) { 
                var link = 'http://www.ncbi.nlm.nih.gov/pubmed?term='+terms[d.source.index]+'[MeSH Major%20Topic%5D%20AND%20'+terms[d.target.index]+'%5BMeSH%20Major%20Topic%5D';
                window.open(link); })
      .attr("d", d3.svg.chord().radius(innerRadius))
      .style("fill", function(d) { return fill(d.target.index); })
      .style("opacity", 1)
      .style("cursor","pointer")
      .on("mouseover", function(){
        d3.selectAll(".chord path").style("opacity",0.1);
        d3.select(this).style("opacity",1);
      })
      .on("mouseleave", function(){
        d3.selectAll(".chord path").style("opacity",1);
      })
      .attr("class","edge")
      .append("svg:title")
      .text(function(d) { return terms[d.source.index]+' AND '+terms[d.target.index]; });

  // Returns an event handler for fading a given chord group.
  function fade(opacity) {
    return function(g, i) {
      chordD.selectAll(".chord path")
          .filter(function(d) { return d.source.index != i && d.target.index != i; })
          .style("opacity", opacity);
    };
  }
}
