var width = jQuery("#forced").width(),
height = 800;

var nodes = [];
var links = [];
var force, plotJSON;

/*
var force = d3.layout.force()
.charge(-120)
.linkDistance(30)
.size([width, height]);
*/
var vis = d3.select("#forced").append("svg:svg")
.attr("width", width)
.attr("height", height)
.attr("pointer-events", "all")
.append('svg:g')
.call(d3.behavior.zoom().on("zoom", redraw))
.append('svg:g');

vis.append('svg:rect')
.attr('width', width)
.attr('height', height)
.attr('fill', 'white');

function redraw() {
    vis.attr("transform",
             "translate(" + d3.event.translate + ")"
             + " scale(" + d3.event.scale + ")");
}

function mergeGraphs(newNodes, newLinks){
    for(i in newLinks){
        sIdx = newLinks[i].source;
        tIdx = newLinks[i].target;
        
        if(nodes.indexOf(newNodes[sIdx]) == -1){
            nodes.push(newNodes[sIdx]);
        }
        newLinks[i].source = nodes.indexOf(newNodes[sIdx]);
        
        if(nodes.indexOf(newNodes[tIdx]) == -1){
            nodes.push(newNodes[tIdx]);
        }
        newLinks[i].target = nodes.indexOf(newNodes[tIdx]);
        links.push(newLinks[i]);
    }
    
}

function init(json){
    plotJSON = json;
    force = self.force = d3.layout.force();
    mergeGraphs(json.nodes, json.links);
    force.nodes(nodes)
    .links(links)
    .gravity(1.0)
    .distance(200)
    .charge(-1000)
    .linkDistance(50)
    .size([width, height])
    .start();
    
    var link = vis.selectAll("g.link")
    .data(links)
    .enter()
    .append("svg:g").attr("class", "link").call(force.drag);
    link.append("svg:line")
    .attr("class", "link")
    .attr("x1", function(d){return d.x1})
    .attr("y1", function(d){return d.y1})
    .attr("x2", function(d){return d.x1})
    .attr("y2", function(d){return d.y2})
    .style("stroke-width", function(d){return 1/d.thickness});
    /*link.append("svg:text")
    .attr("class", "link")
    .attr("x", function(d) { return d.source.x; })
    .attr("y", function(d) { return d.source.y; })
    .text(function(d){return d.name;}).style("display", "none");*/
    
    var node = vis.selectAll("g.node")
    .data(nodes)
    .enter().append("svg:g")
    .attr("class", "node")
    .attr("dx", "80px")
    .attr("dy", "80px")
    .call(force.drag);
    
    node.append("svg:circle")
    .attr("class", "node")
    .attr("r", "5")
    .attr("x", "-8px")
    .attr("y", "-8px")
    .attr("width", "16px")
    .attr("height", "16px")
    .style("fill",  "#0000ff")
    .style("stroke", "#000").append("title")
    .text(function(d) { return d.termName; })
    
    node.append("svg:text")
    .attr("class", "nodetext")
    .attr("dx", 12)
    .attr("dy", ".35em")
    .text(function(d) { return d.termName });
    
    var ticks = 0;
    force.on("tick", function() {
             ticks++;
             if (ticks > 300) {
             force.stop();
             force.charge(0)
             .linkStrength(0)
             .linkDistance(0)
             .gravity(0);
             force.start();
             }
             link.selectAll("line.link").attr("x1", function(d) { return d.source.x; })
             .attr("y1", function(d) { return d.source.y; })
             .attr("x2", function(d) { return d.target.x; })
             .attr("y2", function(d) { return d.target.y; });
             link.selectAll("text.link").attr("x", function(d) { return (d.source.x+d.target.x)/2; })
             .attr("y", function(d) { return (d.source.y+d.target.y)/2; });
             
             node.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")";
                       });
             });
}
