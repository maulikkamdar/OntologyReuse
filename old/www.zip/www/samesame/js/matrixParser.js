var termLocator = [], linkLocator = [];
var terms = [], links = [], parents = [], children = [];
var linkCount = 0, termCount = 0;
var mainTerm = "";
var nbCutoff=5;
/*
d3.json('data/ebola50.json', function(data) {
    mainTerm = data.distance[0].term1;
    for (i in data.distance) {
    	if(termLocator[data.distance[i].term1] == null){
    	    var termName = data.distance[i].term1;
        	terms.push({"id": termCount, "termName": termName, "children": []})
            termLocator[termName] = termCount++;
 			if (i != 0)
 			    children.push(termName);
        }
       	if(termLocator[data.distance[i].term2] == null){
       		var termName = data.distance[i].term2;
            terms.push({"id": termCount, termName: data.distance[i].term2, "children": []})
        	termLocator[termName] = termCount++;
    	}
    }
        console.log(terms);
	//buildChildrenMapRec(mainTerm, data.distance);
	parents.push(mainTerm);
});
/*
function buildChildrenMapRec(term) {
    if (children.length == 0)
        return;
	for (i in terms) {
	    for (j in terms) {
	        
	    }
	}
	for (i in terms[termLocator[term]].children) {
	    buildChildrenMapRec(terms[termLocator[term]].children[i]);
	}
}
*/

/*
d3.tsv('data/ebola50.txt', function (data) {
	for (i in data) {
	    termLocator[data[i].term] = i;
	    terms.push({"id": i, "name": data[i].Term, "children": [], "group": Math.floor((Math.random() * 10) + 1), "dataString" : data[i]})
	}
	//buildChildrenMap();
       buildMatrixMap();
});*/

function buildPhyloTree(distance, jsonStruct) {
    var minimum = 1;
    var pointer = [];
    for (i in distance){
        if (distance[i].term1 == distance[i].term2 || distance[i].pm_dist > 1)
            continue;
        if (distance[i].pm_dist == minimum) {
            pointer.push(i);
        } else {
            minimum = distance[i].pm_dist;
            pointer = []
            pointer.push(i)
        }
    }
    for(i in pointer) {
        distance.remove(i+1);
    }
    
    return jsonStruct;
}

function buildMatrixMap() {
    for(i in terms) {
        for(j in terms) {
            
            if(parseFloat(terms[i].dataString[terms[j].name]) > 1)
                var edgeT = 0;
            else
                var edgeT = parseFloat(terms[i].dataString[terms[j].name]);
            links.push({"id": i +"_" +j, "source": i, "target": j, "value": Math.round(100*edgeT)});
        }
    }
    vizMatrix({"nodes":terms, "links":links});
}

function buildChildrenMap() {
	for(i in terms) {
       minimum = 1;
	   maximum = 0;
       argMaximum = "";
        
	   for(j in terms) {
	       if (i>=j || parseFloat(terms[i].dataString[terms[j].termName]) > 1)
	           continue;
	       else {
	           var edgeT = parseFloat(terms[i].dataString[terms[j].termName]);
               if(terms[i].children.length > nbCutoff-1) {
                   if (edgeT < maximum) {
                       newChildren = [];
                       maximum = 0;
                       links[linkLocator[i + "_" + argMaximum]].disp = false;
                       console.log(i);
                       console.log(argMaximum);
                       for (k in terms[i].children) {
                           if (terms[i].children[k] !== argMaximum) {
                               newChildren.push(terms[i].children[k]);
                               // console.log(terms[i].children[k]);
                               if (links[linkLocator[i + "_" + terms[i].children[k]]].thickness > maximum) {
                                    maximum = links[linkLocator[i + "_" + terms[i].children[k]]].thickness;
                                    argMaximum = terms[i].children[k];
                               }
                           }
                       }
                       newChildren.push(j);
                       links.push({"id": i +"_" +j, "source": i, "target": j, "thickness": edgeT, "disp": true});
                       linkLocator[i + "_" +j] = linkCount++;
                       if (edgeT < minimum)
                           minimum = edgeT;
                       if (edgeT > maximum) {
                           maximum = edgeT;
                           argMaximum = j;
                       }
                       terms[i].children = newChildren;
                       console.log(terms[i].children)
                   }
               } else {
                   links.push({"id": i +"_" +j, "source": i, "target": j, "thickness": edgeT, "disp": true});
                   linkLocator[i +"_" +j] = linkCount++
                   terms[i].children.push(j);
                   if (edgeT < minimum)
                       minimum = edgeT;
                   if (edgeT > maximum) {
                       maximum = edgeT;
                       argMaximum = j;
                   }
               }
	       }
	   }
	   terms[i].minimum = minimum;
	   terms[i].maximum = maximum;
	}
    //init({"nodes":terms, "links":links});
}

var flatFileUrl = 'data/ngly1data.json';
d3.json(flatFileUrl, function(data) {
 vizTree(data.tree);
        visualizeit(data.distance);
});
/*

jQuery( "#searchSubmitBtn" ).click(function( event ) {
    var flatFileUrl = 'data/ebolaDuo.json';
    //var limit = jQuery("#maxMesh").val();
   // var url = "SameService?query="+ jQuery("#searchBox").val() + "&limit=" + limit + "&children="+jQuery("#noChild").val();
   //                                console.log(url);
    $.ajax({
           type : "GET",
           url : flatFileUrl,
           dataType : "json",
           beforeSend : function(data){
                jQuery('.splashScreenExplorer').show();
           },
           success : function(data){
                jQuery('.splashScreenExplorer').hide();
                vizTree(JSON.parse(data).tree);
           }
           });
});*/