var storage = (function() {
    var uid = new Date,
        storage,
        result;
    try {
      (storage = window.localStorage).setItem(uid, uid);
      result = storage.getItem(uid) == uid;
      storage.removeItem(uid);
      return result && storage;
    } catch(e) {}
}());
/*
Array.prototype.remove = function(el) {
    return this.splice(this.indexOf(el), 1);
}
*/
function isInt(value) {
    return !isNaN(value) &&
    parseInt(Number(value)) == value &&
    !isNaN(parseInt(value, 10));
}

/*
 * Input data in the format of {attributes : .... , "value": someValue, "normalizedValue": normalizedValue} for normalization
 * Provided the desired range of normalized Data
 */

function normalizeData(data, maximum, minimum, desMax, desMin) {
	for(i in data){
		var normalizedValue = desMin + (data[i].value - minimum)*(desMax - desMin)/(maximum - minimum);
		if(normalizedValue > 50)
			console.log(data[i].value);
		data[i].normalizedValue = normalizedValue;
	}
	return data;
}

function origData(data, maximum, minimum, desMax, desMin) {
	for(i in data){
		data[i].normalizedValue = data[i].value*50;
	}
	return data;
}


// Create the XHR object.
function createCORSRequest(method, url) {
    var xhr = new XMLHttpRequest();
    if ("withCredentials" in xhr) {
        // XHR for Chrome/Firefox/Opera/Safari.
        xhr.open(method, url, true);
    } else if (typeof XDomainRequest != "undefined") {
        // XDomainRequest for IE.
        xhr = new XDomainRequest();
        xhr.open(method, url);
    } else {
        // CORS not supported.
        xhr = null;
    }
    return xhr;
}

function makeCorsRequest(url, resourceTerm) {
    var xhr = createCORSRequest('GET', url);
    if (!xhr) {
        console.log('CORS not supported');
        return;
    }
    
    // Response handlers.
    xhr.onload = function() {
        var data = xhr.responseText;
        $('#' + resourceTerm + 'sdf_src').val(data);
        new GLmol(resourceTerm+'sdf');
    };
    
    xhr.onerror = function() {
        console.log('Woops, there was an error making the request.');
    };
    
    xhr.send();
}
